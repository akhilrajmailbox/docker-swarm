window.adBlockerActive = false;
