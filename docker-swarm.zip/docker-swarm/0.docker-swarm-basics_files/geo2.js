(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "BANGALORE",
      'continent': "AS",
      'country': "IN",
      'region': "KA"
    },
    'ip':"106.51.39.173"
  }]);
})
//
()

;